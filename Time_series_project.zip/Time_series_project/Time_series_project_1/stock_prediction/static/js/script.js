function getPrediction() {
    fetch("/predict")
        .then(res => res.json())
        .then(data => {
            document.getElementById("output").innerText = "Predicted Price: ₹" + data.prediction;
        });
}
