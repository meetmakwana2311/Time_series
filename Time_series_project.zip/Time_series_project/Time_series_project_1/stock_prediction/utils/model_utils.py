import pandas as pd
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import os

# Create static/plots dir if not exists
os.makedirs("static/plots", exist_ok=True)

def load_data():
    df = pd.read_csv('notebook\BNB-USD.csv')
    return df

def plot_closing_price(df):
    plt.figure(figsize=(10,4))
    plt.plot(df['Close'], label='Closing Price')
    plt.title('BNB Closing Price')
    plt.xlabel('Days')
    plt.ylabel('Price')
    plt.legend()
    plt.savefig('static/plots/closing_price.png')
    plt.close()

def train_model(df):
    # Dummy training (replace with your actual logic)
    prices = df['Close'].values
    x = torch.tensor(prices[:-1], dtype=torch.float32).view(-1,1)
    y = torch.tensor(prices[1:], dtype=torch.float32).view(-1,1)

    model = nn.Linear(1, 1)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

    losses = []
    for epoch in range(50):
        y_pred = model(x)
        loss = criterion(y_pred, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        losses.append(loss.item())

    # Plot training loss
    plt.plot(losses)
    plt.title("Training Loss Curve")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.savefig('static/plots/loss_curve.png')
    plt.close()

    # Predict
    predicted = model(x).detach().numpy()

    # Plot prediction vs actual
    plt.plot(prices[1:], label='Actual')
    plt.plot(predicted, label='Predicted')
    plt.title('Actual vs Predicted')
    plt.legend()
    plt.savefig('static/plots/prediction_vs_actual.png')
    plt.close()
