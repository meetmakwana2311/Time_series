from flask import Flask, render_template
import nbformat
from nbconvert import HTMLExporter

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/code')
def code():
    with open('notebook\‘Stock_Price_Trend_Prediction_using_the_time_series_data.ipynb') as f:
        notebook_content = f.read()
    notebook_node = nbformat.reads(notebook_content, as_version=4)

    html_exporter = HTMLExporter()
    html_exporter.template_name = 'lab'  # Or 'classic' if lab fails
    (body, resources) = html_exporter.from_notebook_node(notebook_node)
    return render_template('code.html', notebook_html=body)

if __name__ == '__main__':
    app.run(debug=True)
